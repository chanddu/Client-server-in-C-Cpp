For compiling client.cpp -> g++ -o "executable name" client.cpp
For compiling server.cpp -> g++ -o "executable name" -I./include/polarssl/ -L./library/ server.cpp -lpolarssl
